# Homora: Cloud-Based Real Estate Intelligence SaaS

## Overview

Homora has been transformed from a self-hosted solution into a fully functional cloud-based SaaS platform. It provides real estate professionals, investors, and renters with AI-powered property analysis, investment scoring, and legal insights through a subscription-based model.

The platform now features live authentication, Stripe billing integration, and working AI tools powered by OpenAI/Groq APIs. Users can subscribe to access premium features and get real-time property intelligence.

## System Architecture

### Frontend Architecture
- **Framework**: React with TypeScript, using Vite for development and build tooling
- **UI Library**: Shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS variables for theming
- **Routing**: Wouter for client-side routing
- **State Management**: React Query (TanStack Query) for server state management
- **Component Structure**: Modular component architecture with clear separation of concerns

### Backend Architecture
- **Server**: Express.js with TypeScript
- **API Design**: RESTful endpoints for property analysis, zoning information, and market metrics
- **Development**: Vite middleware integration for hot module replacement
- **Storage**: In-memory storage implementation with interface for future database integration
- **Data Validation**: Zod schemas for type-safe API contracts

### Database Schema
The application uses Drizzle ORM with PostgreSQL, featuring four main entities:
- **Users**: Basic authentication and user management
- **Properties**: Property data with AI-generated investment analysis
- **Zoning Info**: Municipal zoning laws and regulations by ZIP code
- **Market Metrics**: Local market data and trends

## Key Components

### Landing Page System
- **Navigation**: Sticky navigation with smooth scrolling to sections
- **Hero Section**: Compelling value proposition with gradient background
- **Benefits Section**: Privacy and self-hosting advantages comparison
- **Demo Section**: Interactive property analysis simulator
- **Features Section**: Comprehensive capability showcase
- **Installation Section**: Docker-based setup instructions
- **Tech Stack Section**: Detailed architecture overview

### API Endpoints
- `POST /api/property/analyze`: Property investment analysis with AI insights
- `GET /api/zoning/:zipcode`: Zoning information and legal compliance data
- Market metrics and historical data endpoints (planned)

### Component Library
- Comprehensive UI component system using Radix UI primitives
- Consistent theming with CSS custom properties
- Responsive design patterns for mobile and desktop
- Accessibility-first component implementations

## Data Flow

1. **User Interaction**: Users input property details through the demo interface
2. **API Processing**: Express server validates input using Zod schemas
3. **Analysis Engine**: Mock AI analysis generates investment scores and insights
4. **Data Storage**: Results stored in memory (PostgreSQL in production)
5. **Response**: Structured analysis data returned to frontend
6. **UI Updates**: React components re-render with new analysis results

## External Dependencies

### Development Dependencies
- **Vite**: Build tool and development server
- **TypeScript**: Type safety and developer experience
- **ESBuild**: Production bundling for server-side code
- **Replit Integration**: Development environment optimizations

### Runtime Dependencies
- **React Ecosystem**: React, React DOM, React Query
- **UI Framework**: Radix UI components, Tailwind CSS
- **Database**: Drizzle ORM with Neon Database support
- **Validation**: Zod for runtime type checking
- **Date Handling**: date-fns for date manipulation

### Cloud SaaS Stack
- **Authentication**: Supabase Auth with email/password and OAuth
- **Payments**: Stripe Checkout with subscription webhooks
- **AI Services**: OpenAI/Groq APIs for real-time analysis
- **Database**: Supabase PostgreSQL for user data and subscriptions
- **Hosting**: Replit cloud hosting for immediate deployment

## Deployment Strategy

### Development Environment
- **Replit**: Primary development platform with hot reloading
- **Vite Dev Server**: Fast development with HMR support
- **Memory Storage**: Simplified data persistence for demo purposes

### Production Deployment
- **Docker Compose**: Multi-container deployment with:
  - Web UI container (this Replit project built)
  - API backend container
  - PostgreSQL database container
  - Ollama AI service container
  - n8n automation container
- **Self-Hosted**: Complete independence from external services
- **Privacy-First**: All data processing occurs locally

### Build Process
- **Client Build**: Vite builds React app to `dist/public`
- **Server Build**: ESBuild bundles Express server to `dist/index.js`
- **Static Assets**: Optimized for production serving
- **Environment Configuration**: Database URL and service configuration

## Changelog

```
Changelog:
- June 29, 2025. Initial setup and complete landing page development
- Updated GitHub repository links to point to https://github.com/kgarg2468/Homora
```

## User Preferences

```
Preferred communication style: Simple, everyday language.
```
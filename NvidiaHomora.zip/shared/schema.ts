import { pgTable, text, serial, integer, real, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name"),
  supabaseId: text("supabase_id").unique(),
  subscriptionStatus: text("subscription_status").default("free"),
  stripeCustomerId: text("stripe_customer_id"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const subscriptions = pgTable("subscriptions", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  stripeSubscriptionId: text("stripe_subscription_id").notNull().unique(),
  status: text("status").notNull(), // active, canceled, past_due, etc.
  priceId: text("price_id").notNull(),
  currentPeriodEnd: timestamp("current_period_end"),
  cancelAtPeriodEnd: boolean("cancel_at_period_end").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const properties = pgTable("properties", {
  id: serial("id").primaryKey(),
  zipCode: text("zip_code").notNull(),
  price: integer("price").notNull(),
  propertyType: text("property_type").notNull(),
  investmentScore: real("investment_score"),
  appreciationPotential: text("appreciation_potential"),
  rentalYield: real("rental_yield"),
  riskAssessment: text("risk_assessment"),
  aiInsight: text("ai_insight"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const zoningInfo = pgTable("zoning_info", {
  id: serial("id").primaryKey(),
  zipCode: text("zip_code").notNull(),
  currentZoning: text("current_zoning").notNull(),
  permittedUses: text("permitted_uses").array(),
  recentChanges: text("recent_changes"),
  investmentImpact: text("investment_impact"),
});

export const marketMetrics = pgTable("market_metrics", {
  id: serial("id").primaryKey(),
  zipCode: text("zip_code").notNull(),
  medianPrice: integer("median_price"),
  daysOnMarket: integer("days_on_market"),
  pricePerSqft: integer("price_per_sqft"),
  yearOverYearChange: real("year_over_year_change"),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  supabaseId: true,
  subscriptionStatus: true,
  stripeCustomerId: true,
  createdAt: true,
  updatedAt: true,
});

export const insertSubscriptionSchema = createInsertSchema(subscriptions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
});

export const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
  fullName: z.string().min(2),
});

export const insertPropertySchema = createInsertSchema(properties).omit({
  id: true,
  createdAt: true,
});

export const insertZoningInfoSchema = createInsertSchema(zoningInfo).omit({
  id: true,
});

export const insertMarketMetricsSchema = createInsertSchema(marketMetrics).omit({
  id: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertSubscription = z.infer<typeof insertSubscriptionSchema>;
export type Subscription = typeof subscriptions.$inferSelect;
export type InsertProperty = z.infer<typeof insertPropertySchema>;
export type Property = typeof properties.$inferSelect;
export type InsertZoningInfo = z.infer<typeof insertZoningInfoSchema>;
export type ZoningInfo = typeof zoningInfo.$inferSelect;
export type InsertMarketMetrics = z.infer<typeof insertMarketMetricsSchema>;
export type MarketMetrics = typeof marketMetrics.$inferSelect;
export type LoginData = z.infer<typeof loginSchema>;
export type RegisterData = z.infer<typeof registerSchema>;

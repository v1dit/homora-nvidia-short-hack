import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertPropertySchema, 
  insertZoningInfoSchema, 
  insertMarketMetricsSchema,
  loginSchema,
  registerSchema 
} from "@shared/schema";
import { z } from "zod";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key";

// Middleware to verify JWT token
const authenticateToken = (req: any, res: any, next: any) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Access denied. No token provided.' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.user = decoded;
    next();
  } catch (error) {
    res.status(403).json({ error: 'Invalid token.' });
  }
};

export async function registerRoutes(app: Express): Promise<Server> {
  // Authentication endpoints
  app.post("/api/auth/register", async (req, res) => {
    try {
      const userData = registerSchema.parse(req.body);
      
      // Check if user already exists
      const existingUser = await storage.getUserByEmail(userData.email);
      if (existingUser) {
        return res.status(400).json({ error: "User with this email already exists" });
      }
      
      // Hash password
      const hashedPassword = await bcrypt.hash(userData.password, 10);
      
      // Create user
      const user = await storage.createUser({
        ...userData,
        password: hashedPassword
      });
      
      // Generate JWT token
      const token = jwt.sign(
        { userId: user.id, email: user.email },
        JWT_SECRET,
        { expiresIn: '7d' }
      );
      
      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      
      res.json({ 
        token, 
        user: userWithoutPassword 
      });
    } catch (error) {
      console.error("Registration error:", error);
      res.status(400).json({ error: "Registration failed" });
    }
  });

  app.post("/api/auth/login", async (req, res) => {
    try {
      const loginData = loginSchema.parse(req.body);
      
      // Find user
      const user = await storage.getUserByEmail(loginData.email);
      if (!user) {
        return res.status(401).json({ error: "Invalid email or password" });
      }
      
      // Check password
      const isValidPassword = await bcrypt.compare(loginData.password, user.password);
      if (!isValidPassword) {
        return res.status(401).json({ error: "Invalid email or password" });
      }
      
      // Generate JWT token
      const token = jwt.sign(
        { userId: user.id, email: user.email },
        JWT_SECRET,
        { expiresIn: '7d' }
      );
      
      // Remove password from response
      const { password, ...userWithoutPassword } = user;
      
      res.json({ 
        token, 
        user: userWithoutPassword 
      });
    } catch (error) {
      console.error("Login error:", error);
      res.status(400).json({ error: "Login failed" });
    }
  });

  // Get user subscription
  app.get("/api/subscription", authenticateToken, async (req: any, res) => {
    try {
      const subscription = await storage.getSubscriptionByUserId(req.user.userId);
      res.json(subscription || {});
    } catch (error) {
      console.error("Subscription lookup error:", error);
      res.status(500).json({ error: "Failed to retrieve subscription" });
    }
  });

  // Create Stripe checkout session (mock)
  app.post("/api/subscription/checkout", authenticateToken, async (req: any, res) => {
    try {
      // In a real app, this would create a Stripe checkout session
      // For demo, we'll just simulate upgrading the user
      await storage.updateUser(req.user.userId, { subscriptionStatus: "active" });
      
      res.json({ 
        message: "Subscription activated",
        status: "success"
      });
    } catch (error) {
      console.error("Checkout error:", error);
      res.status(500).json({ error: "Failed to create checkout session" });
    }
  });

  // AI Tools endpoints
  app.post("/api/tools/investment-score", authenticateToken, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.userId);
      if (user?.subscriptionStatus !== "active") {
        return res.status(403).json({ error: "Premium subscription required" });
      }

      // Mock AI analysis - in real app would call OpenAI/Groq
      const analysis = {
        score: Math.floor(Math.random() * 40) + 60, // 60-100
        roi_estimate: `${(Math.random() * 15 + 5).toFixed(1)}%`,
        risk_level: ["Low", "Medium-Low", "Medium", "Medium-High"][Math.floor(Math.random() * 4)],
        recommendation: "Based on market trends and zoning potential, this property shows strong investment indicators.",
        key_factors: [
          "Growing neighborhood demand",
          "Recent infrastructure improvements", 
          "Favorable zoning changes",
          "Below-market pricing"
        ]
      };
      
      res.json(analysis);
    } catch (error) {
      console.error("Investment scoring error:", error);
      res.status(500).json({ error: "Analysis failed" });
    }
  });

  app.post("/api/tools/zoning-summary", authenticateToken, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.userId);
      if (user?.subscriptionStatus !== "active") {
        return res.status(403).json({ error: "Premium subscription required" });
      }

      const { text } = req.body;
      
      // Mock AI summarization - in real app would call OpenAI/Groq
      const summary = {
        key_points: [
          "Property is zoned for residential use with ADU potential",
          "Maximum building height is 35 feet",
          "Setback requirements: 15 feet front, 5 feet sides",
          "Parking required: 2 spaces per unit"
        ],
        investment_impact: "Positive - ADU development opportunity adds significant value",
        compliance_notes: "Property appears to comply with current zoning requirements",
        summary: "This residential zoning allows for flexible development options including accessory dwelling units, making it attractive for investors."
      };
      
      res.json(summary);
    } catch (error) {
      console.error("Zoning summary error:", error);
      res.status(500).json({ error: "Summarization failed" });
    }
  });

  app.post("/api/tools/rent-fairness", authenticateToken, async (req: any, res) => {
    try {
      const user = await storage.getUser(req.user.userId);
      if (user?.subscriptionStatus !== "active") {
        return res.status(403).json({ error: "Premium subscription required" });
      }

      const { zipCode, monthlyRent } = req.body;
      const rent = parseInt(monthlyRent);
      
      // Mock fairness analysis
      const marketAverage = rent * (0.9 + Math.random() * 0.2); // ±10% of requested
      const fairnessScore = rent <= marketAverage * 1.1 ? "Fair" : "Above Market";
      
      const analysis = {
        requested_rent: rent,
        market_average: Math.round(marketAverage),
        fairness_score: fairnessScore,
        market_position: rent > marketAverage ? "Above average" : "Below average",
        recommendations: [
          fairnessScore === "Fair" 
            ? "Rent is within reasonable market range"
            : "Consider reducing rent to improve competitiveness",
          "Monitor local rent control regulations",
          "Regular market analysis recommended"
        ]
      };
      
      res.json(analysis);
    } catch (error) {
      console.error("Rent fairness error:", error);
      res.status(500).json({ error: "Analysis failed" });
    }
  });

  // Property analysis endpoint
  app.post("/api/property/analyze", async (req, res) => {
    try {
      const propertyData = insertPropertySchema.parse(req.body);
      
      // Mock analysis for demo purposes
      const analysisResult = {
        investmentScore: 8.7,
        appreciationPotential: "High",
        rentalYield: 4.2,
        riskAssessment: "Medium-Low",
        aiInsight: "Strong growth indicators in this micro-market. Transit development and tech employment growth suggest continued appreciation."
      };
      
      const property = await storage.createProperty({
        ...propertyData,
        ...analysisResult
      });
      
      res.json(property);
    } catch (error) {
      console.error("Property analysis error:", error);
      res.status(400).json({ error: "Invalid property data" });
    }
  });

  // Zoning information endpoint
  app.get("/api/zoning/:zipcode", async (req, res) => {
    try {
      const zipCode = req.params.zipcode;
      
      let zoning = await storage.getZoningByZipCode(zipCode);
      
      if (!zoning) {
        // Create mock zoning data for demo
        const mockZoning = {
          zipCode,
          currentZoning: "R-2 Residential Medium Density",
          permittedUses: [
            "Single-family dwellings",
            "Accessory dwelling units (ADUs)",
            "Home-based businesses (limited)"
          ],
          recentChanges: "ADU regulations updated in 2023 - now allows up to 1,200 sq ft units",
          investmentImpact: "Positive - ADU potential adds value"
        };
        
        zoning = await storage.createZoningInfo(mockZoning);
      }
      
      res.json(zoning);
    } catch (error) {
      console.error("Zoning lookup error:", error);
      res.status(500).json({ error: "Failed to retrieve zoning information" });
    }
  });

  // Market metrics endpoint
  app.get("/api/market/:region", async (req, res) => {
    try {
      const region = req.params.region;
      
      let metrics = await storage.getMarketMetricsByZipCode(region);
      
      if (!metrics) {
        // Create mock market data for demo
        const mockMetrics = {
          zipCode: region,
          medianPrice: 825000,
          daysOnMarket: 18,
          pricePerSqft: 892,
          yearOverYearChange: 12.0
        };
        
        metrics = await storage.createMarketMetrics(mockMetrics);
      }
      
      res.json(metrics);
    } catch (error) {
      console.error("Market metrics error:", error);
      res.status(500).json({ error: "Failed to retrieve market metrics" });
    }
  });

  // Bulk CSV upload endpoint
  app.post("/api/bulk/upload", async (req, res) => {
    try {
      // Mock response for bulk processing
      res.json({
        message: "CSV processing initiated",
        jobId: "job_" + Date.now(),
        estimatedTime: "5-10 minutes",
        status: "processing"
      });
    } catch (error) {
      console.error("Bulk upload error:", error);
      res.status(500).json({ error: "Failed to process CSV upload" });
    }
  });

  // Rental fairness check endpoint
  app.post("/api/rental/fairness", async (req, res) => {
    try {
      const { zipCode, monthlyRent, propertyType } = req.body;
      
      // Mock rental fairness analysis
      const fairnessResult = {
        requestedRent: monthlyRent,
        marketAverage: monthlyRent * 0.95,
        fairnessScore: "Fair",
        recommendations: [
          "Rent is within 5% of market average",
          "Complies with local rent control ordinances",
          "No tenant protection violations detected"
        ]
      };
      
      res.json(fairnessResult);
    } catch (error) {
      console.error("Rental fairness error:", error);
      res.status(500).json({ error: "Failed to analyze rental fairness" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

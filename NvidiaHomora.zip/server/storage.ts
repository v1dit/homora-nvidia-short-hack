import { 
  users, properties, zoningInfo, marketMetrics, subscriptions,
  type User, type InsertUser,
  type Property, type InsertProperty,
  type ZoningInfo, type InsertZoningInfo,
  type MarketMetrics, type InsertMarketMetrics,
  type Subscription, type InsertSubscription
} from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, updates: Partial<User>): Promise<User | undefined>;
  
  createSubscription(subscription: InsertSubscription): Promise<Subscription>;
  getSubscriptionByUserId(userId: number): Promise<Subscription | undefined>;
  updateSubscription(id: number, updates: Partial<Subscription>): Promise<Subscription | undefined>;
  
  createProperty(property: InsertProperty): Promise<Property>;
  getPropertyById(id: number): Promise<Property | undefined>;
  getPropertiesByZipCode(zipCode: string): Promise<Property[]>;
  
  createZoningInfo(zoning: InsertZoningInfo): Promise<ZoningInfo>;
  getZoningByZipCode(zipCode: string): Promise<ZoningInfo | undefined>;
  
  createMarketMetrics(metrics: InsertMarketMetrics): Promise<MarketMetrics>;
  getMarketMetricsByZipCode(zipCode: string): Promise<MarketMetrics | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private subscriptions: Map<number, Subscription>;
  private properties: Map<number, Property>;
  private zoningInfos: Map<string, ZoningInfo>;
  private marketMetrics: Map<string, MarketMetrics>;
  private currentUserId: number;
  private currentSubscriptionId: number;
  private currentPropertyId: number;
  private currentZoningId: number;
  private currentMetricsId: number;

  constructor() {
    this.users = new Map();
    this.subscriptions = new Map();
    this.properties = new Map();
    this.zoningInfos = new Map();
    this.marketMetrics = new Map();
    this.currentUserId = 1;
    this.currentSubscriptionId = 1;
    this.currentPropertyId = 1;
    this.currentZoningId = 1;
    this.currentMetricsId = 1;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      email: insertUser.email,
      password: insertUser.password,
      fullName: insertUser.fullName || null,
      id,
      supabaseId: null,
      subscriptionStatus: "free",
      stripeCustomerId: null,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(id: number, updates: Partial<User>): Promise<User | undefined> {
    const user = this.users.get(id);
    if (!user) return undefined;
    
    const updatedUser = { ...user, ...updates, updatedAt: new Date() };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  async createSubscription(insertSubscription: InsertSubscription): Promise<Subscription> {
    const id = this.currentSubscriptionId++;
    const subscription: Subscription = { 
      userId: insertSubscription.userId,
      stripeSubscriptionId: insertSubscription.stripeSubscriptionId,
      status: insertSubscription.status,
      priceId: insertSubscription.priceId,
      currentPeriodEnd: insertSubscription.currentPeriodEnd || null,
      cancelAtPeriodEnd: insertSubscription.cancelAtPeriodEnd || null,
      id,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    this.subscriptions.set(id, subscription);
    return subscription;
  }

  async getSubscriptionByUserId(userId: number): Promise<Subscription | undefined> {
    return Array.from(this.subscriptions.values()).find(
      (subscription) => subscription.userId === userId
    );
  }

  async updateSubscription(id: number, updates: Partial<Subscription>): Promise<Subscription | undefined> {
    const subscription = this.subscriptions.get(id);
    if (!subscription) return undefined;
    
    const updatedSubscription = { ...subscription, ...updates, updatedAt: new Date() };
    this.subscriptions.set(id, updatedSubscription);
    return updatedSubscription;
  }

  async createProperty(insertProperty: InsertProperty): Promise<Property> {
    const id = this.currentPropertyId++;
    const property: Property = { 
      zipCode: insertProperty.zipCode,
      price: insertProperty.price,
      propertyType: insertProperty.propertyType,
      investmentScore: insertProperty.investmentScore || null,
      appreciationPotential: insertProperty.appreciationPotential || null,
      rentalYield: insertProperty.rentalYield || null,
      riskAssessment: insertProperty.riskAssessment || null,
      aiInsight: insertProperty.aiInsight || null,
      id,
      createdAt: new Date()
    };
    this.properties.set(id, property);
    return property;
  }

  async getPropertyById(id: number): Promise<Property | undefined> {
    return this.properties.get(id);
  }

  async getPropertiesByZipCode(zipCode: string): Promise<Property[]> {
    return Array.from(this.properties.values()).filter(
      (property) => property.zipCode === zipCode
    );
  }

  async createZoningInfo(insertZoning: InsertZoningInfo): Promise<ZoningInfo> {
    const id = this.currentZoningId++;
    const zoning: ZoningInfo = { 
      zipCode: insertZoning.zipCode,
      currentZoning: insertZoning.currentZoning,
      permittedUses: insertZoning.permittedUses || null,
      recentChanges: insertZoning.recentChanges || null,
      investmentImpact: insertZoning.investmentImpact || null,
      id 
    };
    this.zoningInfos.set(insertZoning.zipCode, zoning);
    return zoning;
  }

  async getZoningByZipCode(zipCode: string): Promise<ZoningInfo | undefined> {
    return this.zoningInfos.get(zipCode);
  }

  async createMarketMetrics(insertMetrics: InsertMarketMetrics): Promise<MarketMetrics> {
    const id = this.currentMetricsId++;
    const metrics: MarketMetrics = { 
      zipCode: insertMetrics.zipCode,
      medianPrice: insertMetrics.medianPrice || null,
      daysOnMarket: insertMetrics.daysOnMarket || null,
      pricePerSqft: insertMetrics.pricePerSqft || null,
      yearOverYearChange: insertMetrics.yearOverYearChange || null,
      id 
    };
    this.marketMetrics.set(insertMetrics.zipCode, metrics);
    return metrics;
  }

  async getMarketMetricsByZipCode(zipCode: string): Promise<MarketMetrics | undefined> {
    return this.marketMetrics.get(zipCode);
  }
}

export const storage = new MemStorage();

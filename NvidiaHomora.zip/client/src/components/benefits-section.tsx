import { Shield, WifiOff, Settings, Check, X, Minus } from "lucide-react";

export default function BenefitsSection() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-secondary mb-4">
            Why Choose Self-Hosted Real Estate Intelligence?
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Unlike Zillow or Redfin, Homora runs entirely on your infrastructure, 
            giving you complete control over your data and analysis.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          <div className="text-center p-6 rounded-xl bg-neutral border border-gray-100 hover:shadow-lg transition-shadow">
            <div className="w-16 h-16 bg-primary bg-opacity-10 rounded-lg flex items-center justify-center mx-auto mb-4">
              <Shield className="text-primary w-8 h-8" />
            </div>
            <h3 className="text-xl font-semibold mb-3">Data Privacy</h3>
            <p className="text-gray-600">Your property data, client information, and analysis never leave your servers. Complete privacy guaranteed.</p>
          </div>

          <div className="text-center p-6 rounded-xl bg-neutral border border-gray-100 hover:shadow-lg transition-shadow">
            <div className="w-16 h-16 bg-accent bg-opacity-10 rounded-lg flex items-center justify-center mx-auto mb-4">
              <WifiOff className="text-accent w-8 h-8" />
            </div>
            <h3 className="text-xl font-semibold mb-3">Offline Ready</h3>
            <p className="text-gray-600">Works completely offline. Perfect for remote areas or when internet connectivity is unreliable.</p>
          </div>

          <div className="text-center p-6 rounded-xl bg-neutral border border-gray-100 hover:shadow-lg transition-shadow">
            <div className="w-16 h-16 bg-blue-500 bg-opacity-10 rounded-lg flex items-center justify-center mx-auto mb-4">
              <Settings className="text-blue-500 w-8 h-8" />
            </div>
            <h3 className="text-xl font-semibold mb-3">Fully Customizable</h3>
            <p className="text-gray-600">Adapt the system for agencies, NGOs, investors, or specific market needs. Open source flexibility.</p>
          </div>
        </div>

        <div className="bg-neutral rounded-xl p-8 border border-gray-100">
          <h3 className="text-2xl font-bold text-center mb-8">Homora vs Traditional Platforms</h3>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="text-left py-4 px-4">Feature</th>
                  <th className="text-center py-4 px-4 text-accent font-bold">Homora</th>
                  <th className="text-center py-4 px-4 text-gray-500">Zillow/Redfin</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                <tr>
                  <td className="py-4 px-4 font-medium">Data Privacy</td>
                  <td className="py-4 px-4 text-center"><Check className="text-accent w-5 h-5 mx-auto" /></td>
                  <td className="py-4 px-4 text-center"><X className="text-red-500 w-5 h-5 mx-auto" /></td>
                </tr>
                <tr>
                  <td className="py-4 px-4 font-medium">Offline Operation</td>
                  <td className="py-4 px-4 text-center"><Check className="text-accent w-5 h-5 mx-auto" /></td>
                  <td className="py-4 px-4 text-center"><X className="text-red-500 w-5 h-5 mx-auto" /></td>
                </tr>
                <tr>
                  <td className="py-4 px-4 font-medium">Custom Analysis</td>
                  <td className="py-4 px-4 text-center"><Check className="text-accent w-5 h-5 mx-auto" /></td>
                  <td className="py-4 px-4 text-center"><Minus className="text-yellow-500 w-5 h-5 mx-auto" /></td>
                </tr>
                <tr>
                  <td className="py-4 px-4 font-medium">Investment Scoring</td>
                  <td className="py-4 px-4 text-center"><Check className="text-accent w-5 h-5 mx-auto" /></td>
                  <td className="py-4 px-4 text-center"><Minus className="text-yellow-500 w-5 h-5 mx-auto" /></td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </section>
  );
}

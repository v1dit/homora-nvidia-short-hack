import { Button } from "@/components/ui/button";
import { Download, Play, Github, Twitter, Linkedin } from "lucide-react";

export default function CTASection() {
  const handleDownloadCTA = () => {
    window.open("https://github.com/kgarg2468/Homora", "_blank");
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const openGitHub = () => {
    window.open("https://github.com/krishgarg", "_blank");
  };

  const openTwitter = () => {
    window.open("https://twitter.com/krishgarg", "_blank");
  };

  const openLinkedIn = () => {
    window.open("https://linkedin.com/in/krishgarg", "_blank");
  };

  return (
    <section className="py-20 gradient-cta text-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-3xl lg:text-4xl font-bold mb-6">
          Ready to Take Control of Your Real Estate Data?
        </h2>
        <p className="text-xl text-blue-100 mb-8 leading-relaxed">
          Join the privacy-first movement in real estate technology. 
          Get started with Homora today and experience truly private, self-hosted property intelligence.
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
          <Button 
            onClick={() => window.location.href = "/auth"}
            className="bg-accent text-white px-8 py-4 h-auto text-lg font-semibold hover:bg-green-600 transition-all transform hover:scale-105"
          >
            <Play className="mr-2 w-5 h-5" />
            Start Free Trial
          </Button>
          <Button 
            onClick={scrollToTop}
            variant="outline"
            className="border-2 border-white text-white px-8 py-4 h-auto text-lg font-semibold hover:bg-white hover:text-primary transition-all"
          >
            <Download className="mr-2 w-5 h-5" />
            View Demo
          </Button>
        </div>

        <div className="border-t border-blue-400 border-opacity-30 pt-8">
          <p className="text-blue-200 mb-4">Built by Krish Garg • Open Source • MIT License</p>
          <div className="flex justify-center space-x-6">
            <button onClick={openGitHub} className="text-blue-200 hover:text-white transition-colors">
              <Github className="w-6 h-6" />
            </button>
            <button onClick={openTwitter} className="text-blue-200 hover:text-white transition-colors">
              <Twitter className="w-6 h-6" />
            </button>
            <button onClick={openLinkedIn} className="text-blue-200 hover:text-white transition-colors">
              <Linkedin className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}

import { Button } from "@/components/ui/button";
import { Play, Download } from "lucide-react";

export default function HeroSection() {
  const scrollToDemo = () => {
    const element = document.getElementById('demo');
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleDownload = () => {
    window.open("https://github.com/kgarg2468/Homora", "_blank");
  };

  return (
    <section className="relative gradient-hero text-white">
      <div className="absolute inset-0 bg-black bg-opacity-30"></div>
      <div 
        style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1560472354-b33ff0c44a43?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1926&h=1080')",
          backgroundSize: 'cover',
          backgroundPosition: 'center'
        }}
        className="absolute inset-0 opacity-20"
      ></div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 lg:py-32">
        <div className="max-w-3xl">
          <h1 className="text-4xl lg:text-6xl font-bold mb-6 leading-tight">
            Privacy-First Real Estate Intelligence
          </h1>
          <p className="text-xl lg:text-2xl mb-8 text-blue-100 leading-relaxed">
            Self-hosted analysis, investment scoring, and legal insights that never leave your machine. 
            Built for agencies, investors, and homebuyers who value privacy.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 mb-12">
            <Button 
              onClick={() => window.location.href = "/auth"}
              className="bg-accent text-white px-8 py-4 h-auto text-lg font-semibold hover:bg-green-600 transition-all transform hover:scale-105"
            >
              <Play className="mr-2 w-5 h-5" />
              Try AI Tools Now
            </Button>
            <Button 
              onClick={scrollToDemo}
              variant="outline"
              className="bg-white text-primary px-8 py-4 h-auto text-lg font-semibold hover:bg-gray-50 transition-all border-2 border-white hover:border-white"
            >
              <Download className="mr-2 w-5 h-5" />
              View Demo
            </Button>
          </div>

          <div className="grid grid-cols-3 gap-8 pt-8 border-t border-blue-400 border-opacity-30">
            <div className="text-center">
              <div className="text-2xl font-bold text-accent">100%</div>
              <div className="text-sm text-blue-200">Privacy Protected</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-accent">Offline</div>
              <div className="text-sm text-blue-200">Works Locally</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-accent">Open</div>
              <div className="text-sm text-blue-200">Source Available</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

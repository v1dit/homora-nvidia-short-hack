import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Brain, FileText, TrendingUp, Scale, Loader2, Lock } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface AIToolsSectionProps {
  isPremium: boolean;
}

export default function AIToolsSection({ isPremium }: AIToolsSectionProps) {
  const { toast } = useToast();
  const [activeTool, setActiveTool] = useState<string | null>(null);

  // Investment Scoring Tool
  const [investmentData, setInvestmentData] = useState({
    zipCode: "",
    price: "",
    propertyType: "",
    sqft: "",
    rentPotential: ""
  });

  // Zoning Summarizer Tool
  const [zoningText, setZoningText] = useState("");

  // Rent Fairness Tool
  const [rentData, setRentData] = useState({
    zipCode: "",
    monthlyRent: "",
    propertyType: ""
  });

  const investmentMutation = useMutation({
    mutationFn: (data: any) => apiRequest("/api/tools/investment-score", "POST", data),
    onSuccess: (result) => {
      toast({
        title: "Analysis Complete",
        description: "Investment scoring has been completed successfully.",
      });
      setActiveResult(result);
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Analysis Failed",
        description: "Unable to complete investment analysis. Please try again.",
      });
    },
  });

  const zoningMutation = useMutation({
    mutationFn: (data: { text: string }) => apiRequest("/api/tools/zoning-summary", "POST", data),
    onSuccess: (result) => {
      toast({
        title: "Summary Generated",
        description: "Legal document summary has been generated.",
      });
      setActiveResult(result);
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Summary Failed",
        description: "Unable to generate summary. Please try again.",
      });
    },
  });

  const rentFairnessMutation = useMutation({
    mutationFn: (data: any) => apiRequest("/api/tools/rent-fairness", "POST", data),
    onSuccess: (result) => {
      toast({
        title: "Fairness Check Complete",
        description: "Rent fairness analysis has been completed.",
      });
      setActiveResult(result);
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Analysis Failed",
        description: "Unable to complete rent fairness check.",
      });
    },
  });

  const [activeResult, setActiveResult] = useState<any>(null);

  const handleInvestmentScore = () => {
    if (!isPremium) {
      toast({
        variant: "destructive",
        title: "Premium Required",
        description: "Upgrade to Pro to access AI investment scoring.",
      });
      return;
    }
    investmentMutation.mutate(investmentData);
  };

  const handleZoningSummary = () => {
    if (!isPremium) {
      toast({
        variant: "destructive",
        title: "Premium Required",
        description: "Upgrade to Pro to access AI document analysis.",
      });
      return;
    }
    zoningMutation.mutate({ text: zoningText });
  };

  const handleRentFairness = () => {
    if (!isPremium) {
      toast({
        variant: "destructive",
        title: "Premium Required",
        description: "Upgrade to Pro to access rent fairness analysis.",
      });
      return;
    }
    rentFairnessMutation.mutate(rentData);
  };

  const tools = [
    {
      id: "investment",
      title: "Investment Scoring",
      description: "AI-powered property investment analysis with ROI predictions",
      icon: TrendingUp,
      premium: true,
    },
    {
      id: "zoning",
      title: "Legal Document Summarizer",
      description: "Automatically summarize zoning laws and HOA documents",
      icon: FileText,
      premium: true,
    },
    {
      id: "rent-fairness",
      title: "Rent Fairness Checker",
      description: "Compare rental prices against market averages and regulations",
      icon: Scale,
      premium: true,
    }
  ];

  return (
    <div className="space-y-6">
      {!isPremium && (
        <Card className="border-amber-200 bg-amber-50">
          <CardContent className="p-6">
            <div className="flex items-center space-x-3">
              <Lock className="text-amber-600 w-5 h-5" />
              <div>
                <h3 className="font-semibold text-amber-800">Premium Features</h3>
                <p className="text-amber-700 text-sm">Upgrade to Pro to access all AI-powered tools and advanced analytics.</p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid md:grid-cols-3 gap-6">
        {tools.map((tool) => {
          const IconComponent = tool.icon;
          const isDisabled = tool.premium && !isPremium;
          
          return (
            <Card 
              key={tool.id} 
              className={`cursor-pointer transition-all hover:shadow-lg ${
                activeTool === tool.id ? 'ring-2 ring-primary' : ''
              } ${isDisabled ? 'opacity-60' : ''}`}
              onClick={() => !isDisabled && setActiveTool(activeTool === tool.id ? null : tool.id)}
            >
              <CardHeader>
                <div className="flex items-center justify-between">
                  <IconComponent className="text-primary w-6 h-6" />
                  {tool.premium && (
                    <Badge variant={isPremium ? "default" : "secondary"} className="text-xs">
                      {isPremium ? "Pro" : "Premium"}
                    </Badge>
                  )}
                </div>
                <CardTitle className="text-lg">{tool.title}</CardTitle>
                <CardDescription>{tool.description}</CardDescription>
              </CardHeader>
            </Card>
          );
        })}
      </div>

      {/* Investment Scoring Tool */}
      {activeTool === "investment" && isPremium && (
        <Card>
          <CardHeader>
            <CardTitle>Investment Scoring Analysis</CardTitle>
            <CardDescription>Enter property details for AI-powered investment analysis</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="zipCode">ZIP Code</Label>
                <Input
                  id="zipCode"
                  value={investmentData.zipCode}
                  onChange={(e) => setInvestmentData({...investmentData, zipCode: e.target.value})}
                  placeholder="94102"
                />
              </div>
              <div>
                <Label htmlFor="price">Property Price</Label>
                <Input
                  id="price"
                  value={investmentData.price}
                  onChange={(e) => setInvestmentData({...investmentData, price: e.target.value})}
                  placeholder="750000"
                />
              </div>
              <div>
                <Label htmlFor="propertyType">Property Type</Label>
                <Select value={investmentData.propertyType} onValueChange={(value) => setInvestmentData({...investmentData, propertyType: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Single Family Home">Single Family Home</SelectItem>
                    <SelectItem value="Condo">Condo</SelectItem>
                    <SelectItem value="Townhouse">Townhouse</SelectItem>
                    <SelectItem value="Multi-Family">Multi-Family</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="sqft">Square Footage</Label>
                <Input
                  id="sqft"
                  value={investmentData.sqft}
                  onChange={(e) => setInvestmentData({...investmentData, sqft: e.target.value})}
                  placeholder="1200"
                />
              </div>
            </div>
            <Button 
              onClick={handleInvestmentScore} 
              disabled={investmentMutation.isPending}
              className="w-full"
            >
              {investmentMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 w-4 h-4 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Brain className="mr-2 w-4 h-4" />
                  Analyze Investment Potential
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Zoning Summarizer Tool */}
      {activeTool === "zoning" && isPremium && (
        <Card>
          <CardHeader>
            <CardTitle>Legal Document Summarizer</CardTitle>
            <CardDescription>Paste legal text or zoning documents for AI analysis</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="zoningText">Legal Document Text</Label>
              <Textarea
                id="zoningText"
                value={zoningText}
                onChange={(e) => setZoningText(e.target.value)}
                placeholder="Paste zoning laws, HOA documents, or other legal text here..."
                rows={6}
              />
            </div>
            <Button 
              onClick={handleZoningSummary} 
              disabled={zoningMutation.isPending || !zoningText.trim()}
              className="w-full"
            >
              {zoningMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 w-4 h-4 animate-spin" />
                  Summarizing...
                </>
              ) : (
                <>
                  <FileText className="mr-2 w-4 h-4" />
                  Generate Summary
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Rent Fairness Tool */}
      {activeTool === "rent-fairness" && isPremium && (
        <Card>
          <CardHeader>
            <CardTitle>Rent Fairness Analysis</CardTitle>
            <CardDescription>Check if rental pricing is fair compared to market rates</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="rentZipCode">ZIP Code</Label>
                <Input
                  id="rentZipCode"
                  value={rentData.zipCode}
                  onChange={(e) => setRentData({...rentData, zipCode: e.target.value})}
                  placeholder="94102"
                />
              </div>
              <div>
                <Label htmlFor="monthlyRent">Monthly Rent</Label>
                <Input
                  id="monthlyRent"
                  value={rentData.monthlyRent}
                  onChange={(e) => setRentData({...rentData, monthlyRent: e.target.value})}
                  placeholder="3500"
                />
              </div>
            </div>
            <Button 
              onClick={handleRentFairness} 
              disabled={rentFairnessMutation.isPending}
              className="w-full"
            >
              {rentFairnessMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 w-4 h-4 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Scale className="mr-2 w-4 h-4" />
                  Check Rent Fairness
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      )}

      {/* Results Display */}
      {activeResult && (
        <Card className="bg-accent/5 border-accent">
          <CardHeader>
            <CardTitle className="text-accent">Analysis Results</CardTitle>
          </CardHeader>
          <CardContent>
            <pre className="whitespace-pre-wrap text-sm bg-white p-4 rounded border">
              {JSON.stringify(activeResult, null, 2)}
            </pre>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
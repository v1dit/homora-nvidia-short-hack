import { TrendingUp, FileText, Brain, Upload, Scale, Server } from "lucide-react";

export default function FeaturesSection() {
  const features = [
    {
      icon: TrendingUp,
      title: "Investment Scoring",
      description: "AI-powered analysis of property investment potential using local market data, zoning laws, and economic indicators.",
      badge: "LLM-Powered Analysis",
      color: "text-primary"
    },
    {
      icon: FileText,
      title: "Legal Doc Analysis",
      description: "Automated summarization of zoning laws, HOA documents, and municipal regulations affecting your property.",
      badge: "Document Processing",
      color: "text-accent"
    },
    {
      icon: Brain,
      title: "Local LLM Support",
      description: "Powered by Ollama with llama3 and other models running entirely on your hardware. No external API calls.",
      badge: "Privacy Protected",
      color: "text-blue-500"
    },
    {
      icon: Upload,
      title: "Bulk CSV Processing",
      description: "Upload property lists and get automated analysis reports. Perfect for agents managing multiple listings.",
      badge: "n8n Automation",
      color: "text-purple-500"
    },
    {
      icon: Scale,
      title: "Rental Fairness Check",
      description: "Compare rental prices against local averages and tenant protection laws to ensure fair pricing.",
      badge: "Market Analysis",
      color: "text-orange-500"
    },
    {
      icon: Server,
      title: "Offline Operation",
      description: "Full functionality without internet connection. Your data and analysis capabilities work anywhere.",
      badge: "Self-Contained",
      color: "text-red-500"
    }
  ];

  return (
    <section id="features" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-secondary mb-4">
            Complete Real Estate Intelligence Suite
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Everything you need for smart real estate decisions, running entirely on your infrastructure.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const IconComponent = feature.icon;
            return (
              <div key={index} className="bg-neutral rounded-xl p-6 border border-gray-100 hover:shadow-lg transition-all hover:border-primary group">
                <div className="w-12 h-12 bg-primary bg-opacity-10 rounded-lg flex items-center justify-center mb-4 group-hover:bg-primary group-hover:bg-opacity-20 transition-colors">
                  <IconComponent className={`${feature.color} w-6 h-6`} />
                </div>
                <h3 className="text-xl font-semibold mb-3">{feature.title}</h3>
                <p className="text-gray-600 mb-4">{feature.description}</p>
                <div className={`text-sm ${feature.color} font-medium`}>{feature.badge}</div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}

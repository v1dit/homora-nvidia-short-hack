import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Github, Book, Info } from "lucide-react";

export default function InstallationSection() {
  const handleGitHubDownload = () => {
    window.open("https://github.com/kgarg2468/Homora", "_blank");
  };

  const showDocumentation = () => {
    window.open("https://github.com/kgarg2468/Homora/blob/main/README.md", "_blank");
  };

  const services = [
    {
      name: "Main UI Interface",
      description: "Web dashboard and analysis tools",
      port: ":8000",
      color: "bg-accent"
    },
    {
      name: "Ollama LLM API",
      description: "Local language models",
      port: ":11434",
      color: "bg-blue-500"
    },
    {
      name: "n8n Automation",
      description: "Workflow and data processing",
      port: ":5678",
      color: "bg-purple-500"
    },
    {
      name: "PostgreSQL Database",
      description: "Data storage and analytics",
      port: ":5432",
      color: "bg-red-500"
    }
  ];

  return (
    <section id="install" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-secondary mb-4">
            Get Started in Minutes
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Simple Docker-based installation gets you running quickly. No complex setup or external dependencies required.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h3 className="text-2xl font-bold mb-8">Quick Installation</h3>
            
            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center font-bold text-sm">1</div>
                <div>
                  <h4 className="font-semibold text-lg mb-2">Download from GitHub</h4>
                  <p className="text-gray-600 mb-3">Clone the repository with all necessary components and configurations.</p>
                  <div className="bg-secondary text-white p-3 rounded-lg font-mono text-sm">
                    git clone https://github.com/kgarg2468/Homora.git
                  </div>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center font-bold text-sm">2</div>
                <div>
                  <h4 className="font-semibold text-lg mb-2">Navigate to Directory</h4>
                  <p className="text-gray-600 mb-3">Enter the project directory to access all components.</p>
                  <div className="bg-secondary text-white p-3 rounded-lg font-mono text-sm">
                    cd Homora
                  </div>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-primary text-white rounded-full flex items-center justify-center font-bold text-sm">3</div>
                <div>
                  <h4 className="font-semibold text-lg mb-2">Start with Docker</h4>
                  <p className="text-gray-600 mb-3">Launch all services including AI models, database, and web interface.</p>
                  <div className="bg-secondary text-white p-3 rounded-lg font-mono text-sm">
                    docker-compose up --build
                  </div>
                </div>
              </div>

              <div className="flex items-start space-x-4">
                <div className="w-8 h-8 bg-accent text-white rounded-full flex items-center justify-center font-bold text-sm">✓</div>
                <div>
                  <h4 className="font-semibold text-lg mb-2">Access Your Instance</h4>
                  <p className="text-gray-600">Open your browser and start analyzing properties locally.</p>
                </div>
              </div>
            </div>

            <div className="mt-8">
              <Button 
                onClick={handleGitHubDownload}
                className="bg-primary text-white hover:bg-blue-700 mr-4"
              >
                <Github className="mr-2 w-4 h-4" />
                Download from GitHub
              </Button>
              <Button 
                onClick={showDocumentation}
                variant="outline"
                className="border-2 border-primary text-primary hover:bg-primary hover:text-white"
              >
                <Book className="mr-2 w-4 h-4" />
                View Documentation
              </Button>
            </div>
          </div>

          <Card className="shadow-lg border border-gray-100">
            <CardContent className="p-8">
              <h3 className="text-xl font-bold mb-6">Local Services Dashboard</h3>
              
              <div className="space-y-4">
                {services.map((service, index) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-neutral rounded-lg border border-gray-100">
                    <div className="flex items-center space-x-3">
                      <div className={`w-3 h-3 ${service.color} rounded-full`}></div>
                      <div>
                        <div className="font-medium">{service.name}</div>
                        <div className="text-sm text-gray-500">{service.description}</div>
                      </div>
                    </div>
                    <code className="text-sm bg-gray-100 px-2 py-1 rounded">{service.port}</code>
                  </div>
                ))}
              </div>

              <div className="mt-6 pt-6 border-t border-gray-200">
                <div className="text-sm text-gray-600 flex items-center">
                  <Info className="mr-2 text-blue-500 w-4 h-4" />
                  All services run locally with no external dependencies required.
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
}

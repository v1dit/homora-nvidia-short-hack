import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ExternalLink } from "lucide-react";

export default function TechStackSection() {
  const techStack = [
    {
      title: "Frontend & UI",
      badge: "Web",
      badgeColor: "bg-blue-100 text-blue-800",
      items: [
        { label: "Framework", value: "React + Tailwind CSS" },
        { label: "Location", value: "Replit (Development)" }
      ]
    },
    {
      title: "Backend API",
      badge: "Docker",
      badgeColor: "bg-green-100 text-green-800",
      items: [
        { label: "Framework", value: "FastAPI / Express.js" },
        { label: "Deployment", value: "Docker Container" }
      ]
    },
    {
      title: "AI & Automation",
      badge: "Local",
      badgeColor: "bg-purple-100 text-purple-800",
      items: [
        { label: "LLM Engine", value: "Ollama (llama3)" },
        { label: "Workflows", value: "n8n Automation" }
      ]
    },
    {
      title: "Data Storage",
      badge: "Database",
      badgeColor: "bg-red-100 text-red-800",
      items: [
        { label: "Database", value: "PostgreSQL" },
        { label: "Analytics", value: "Built-in Reporting" }
      ]
    }
  ];

  const apiEndpoints = [
    {
      method: "POST",
      endpoint: "/api/property/analyze",
      description: "Analyze property investment potential and generate scoring",
      methodColor: "bg-green-100 text-green-800"
    },
    {
      method: "GET",
      endpoint: "/api/zoning/:zipcode",
      description: "Retrieve zoning information and legal summaries",
      methodColor: "bg-blue-100 text-blue-800"
    },
    {
      method: "POST",
      endpoint: "/api/bulk/upload",
      description: "Upload CSV files for batch property analysis",
      methodColor: "bg-green-100 text-green-800"
    },
    {
      method: "GET",
      endpoint: "/api/market/:region",
      description: "Market data and pricing trends for specific regions",
      methodColor: "bg-blue-100 text-blue-800"
    },
    {
      method: "POST",
      endpoint: "/api/rental/fairness",
      description: "Check rental pricing against local market and regulations",
      methodColor: "bg-green-100 text-green-800"
    }
  ];

  const roadmapItems = [
    { completed: true, text: "Replace mock API with real backend routes" },
    { completed: false, text: "Build property upload → investment scoring pipeline" },
    { completed: false, text: "Automate legal doc summarization with Ollama" },
    { completed: false, text: "Add user-specific dashboards (agency, buyer, tenant)" }
  ];

  const viewFullAPIDoc = () => {
    window.open("https://github.com/kgarg2468/Homora/blob/main/API.md", "_blank");
  };

  return (
    <section id="docs" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-secondary mb-4">
            Built for Developers
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Modern stack with clear APIs, comprehensive documentation, and extensible architecture.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          <div>
            <h3 className="text-2xl font-bold mb-8">Technology Stack</h3>
            
            <div className="space-y-6">
              {techStack.map((stack, index) => (
                <Card key={index} className="border border-gray-200">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="font-semibold text-lg">{stack.title}</h4>
                      <Badge className={stack.badgeColor}>{stack.badge}</Badge>
                    </div>
                    <div className="space-y-2 text-sm">
                      {stack.items.map((item, itemIndex) => (
                        <div key={itemIndex} className="flex justify-between">
                          <span>{item.label}</span>
                          <span className="font-medium">{item.value}</span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          <div>
            <h3 className="text-2xl font-bold mb-8">API Endpoints</h3>
            
            <Card className="bg-neutral border border-gray-100">
              <CardContent className="p-6">
                <div className="space-y-4">
                  {apiEndpoints.map((endpoint, index) => (
                    <div key={index} className={`${index < apiEndpoints.length - 1 ? 'border-b border-gray-200 pb-4' : ''}`}>
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-mono text-sm">{endpoint.endpoint}</span>
                        <Badge className={endpoint.methodColor}>{endpoint.method}</Badge>
                      </div>
                      <p className="text-sm text-gray-600">{endpoint.description}</p>
                    </div>
                  ))}
                </div>

                <div className="mt-6 pt-6 border-t border-gray-200">
                  <Button 
                    onClick={viewFullAPIDoc}
                    variant="link" 
                    className="text-primary hover:text-blue-700 font-medium text-sm p-0"
                  >
                    <ExternalLink className="mr-2 w-4 h-4" />
                    View Full API Documentation
                  </Button>
                </div>
              </CardContent>
            </Card>

            <div className="mt-8">
              <h4 className="text-lg font-semibold mb-4">Development Roadmap</h4>
              <div className="space-y-3">
                {roadmapItems.map((item, index) => (
                  <div key={index} className="flex items-center space-x-3">
                    <div className={`w-3 h-3 ${item.completed ? 'bg-accent' : 'bg-gray-300'} rounded-full`}></div>
                    <span className="text-gray-700">{item.text}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

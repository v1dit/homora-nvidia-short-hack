import { Home } from "lucide-react";

export default function Footer() {
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="bg-secondary text-gray-300 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid md:grid-cols-4 gap-8">
          <div>
            <div className="flex items-center space-x-3 mb-4">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Home className="text-white w-5 h-5" />
              </div>
              <span className="text-xl font-bold text-white">Homora</span>
            </div>
            <p className="text-sm">Privacy-first real estate intelligence that runs entirely on your infrastructure.</p>
          </div>
          
          <div>
            <h4 className="font-semibold text-white mb-4">Product</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <button 
                  onClick={() => scrollToSection('features')} 
                  className="hover:text-white transition-colors"
                >
                  Features
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('demo')} 
                  className="hover:text-white transition-colors"
                >
                  Try Demo
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('install')} 
                  className="hover:text-white transition-colors"
                >
                  Installation
                </button>
              </li>
              <li>
                <button 
                  onClick={() => scrollToSection('docs')} 
                  className="hover:text-white transition-colors"
                >
                  Documentation
                </button>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold text-white mb-4">Use Cases</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="#" className="hover:text-white transition-colors">Real Estate Agencies</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Property Investors</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Homebuyers</a></li>
              <li><a href="#" className="hover:text-white transition-colors">Tenant Rights NGOs</a></li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold text-white mb-4">Resources</h4>
            <ul className="space-y-2 text-sm">
              <li><a href="https://github.com/kgarg2468/Homora" className="hover:text-white transition-colors">GitHub Repository</a></li>
              <li><a href="https://github.com/kgarg2468/Homora/blob/main/API.md" className="hover:text-white transition-colors">API Documentation</a></li>
              <li><a href="https://github.com/kgarg2468/Homora/blob/main/docker-compose.yml" className="hover:text-white transition-colors">Docker Setup</a></li>
              <li><a href="https://github.com/kgarg2468/Homora/blob/main/CONTRIBUTING.md" className="hover:text-white transition-colors">Contributing Guide</a></li>
            </ul>
          </div>
        </div>
        
        <div className="border-t border-gray-700 mt-8 pt-8 text-center text-sm">
          <p>&copy; 2024 Homora. Open source under MIT License. Built for privacy-conscious real estate professionals.</p>
        </div>
      </div>
    </footer>
  );
}

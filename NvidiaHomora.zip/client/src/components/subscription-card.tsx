import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Crown, Check, CreditCard, Calendar } from "lucide-react";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface User {
  id: number;
  email: string;
  fullName: string;
  subscriptionStatus: string;
}

interface Subscription {
  id: number;
  status: string;
  priceId: string;
  currentPeriodEnd: string;
  cancelAtPeriodEnd: boolean;
}

interface SubscriptionCardProps {
  user: User;
  subscription?: Subscription | null;
}

export default function SubscriptionCard({ user, subscription }: SubscriptionCardProps) {
  const { toast } = useToast();
  const isPremium = user.subscriptionStatus === "active" || subscription?.status === "active";

  const createCheckoutMutation = useMutation({
    mutationFn: () => apiRequest("/api/subscription/checkout", "POST", {}),
    onSuccess: (response: any) => {
      if (response.url) {
        window.location.href = response.url;
      }
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Payment Failed",
        description: "Unable to create checkout session. Please try again.",
      });
    },
  });

  const cancelSubscriptionMutation = useMutation({
    mutationFn: () => apiRequest("/api/subscription/cancel", "POST", {}),
    onSuccess: () => {
      toast({
        title: "Subscription Updated",
        description: "Your subscription will be cancelled at the end of the current period.",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Update Failed",
        description: "Unable to update subscription. Please try again.",
      });
    },
  });

  const features = [
    "AI-powered investment scoring",
    "Legal document summarization",
    "Rent fairness analysis",
    "Market trend insights",
    "Unlimited property analyses",
    "Priority customer support"
  ];

  if (isPremium) {
    return (
      <div className="space-y-6">
        <Card className="border-accent bg-accent/5">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Crown className="text-accent w-6 h-6" />
                <div>
                  <CardTitle className="text-accent">Pro Subscription</CardTitle>
                  <CardDescription>You have access to all premium features</CardDescription>
                </div>
              </div>
              <Badge className="bg-accent text-white">Active</Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            {subscription && (
              <div className="grid md:grid-cols-2 gap-4">
                <div className="flex items-center space-x-2">
                  <Calendar className="text-gray-400 w-4 h-4" />
                  <span className="text-sm">
                    Next billing: {new Date(subscription.currentPeriodEnd).toLocaleDateString()}
                  </span>
                </div>
                <div className="flex items-center space-x-2">
                  <CreditCard className="text-gray-400 w-4 h-4" />
                  <span className="text-sm">$19/month</span>
                </div>
              </div>
            )}
            
            <div className="space-y-2">
              <h4 className="font-semibold">Included Features:</h4>
              <div className="grid md:grid-cols-2 gap-2">
                {features.map((feature, index) => (
                  <div key={index} className="flex items-center space-x-2">
                    <Check className="text-accent w-4 h-4" />
                    <span className="text-sm">{feature}</span>
                  </div>
                ))}
              </div>
            </div>

            {subscription && !subscription.cancelAtPeriodEnd && (
              <Button 
                variant="outline" 
                onClick={() => cancelSubscriptionMutation.mutate()}
                disabled={cancelSubscriptionMutation.isPending}
                className="w-full"
              >
                {cancelSubscriptionMutation.isPending ? "Updating..." : "Cancel Subscription"}
              </Button>
            )}

            {subscription?.cancelAtPeriodEnd && (
              <div className="bg-amber-50 border border-amber-200 rounded-lg p-4">
                <p className="text-amber-800 text-sm">
                  Your subscription will end on {new Date(subscription.currentPeriodEnd).toLocaleDateString()}.
                  You'll continue to have access until then.
                </p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Upgrade to Pro</CardTitle>
          <CardDescription>
            Unlock powerful AI tools for real estate analysis and decision making
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="text-center">
            <div className="text-4xl font-bold text-primary mb-2">$19</div>
            <div className="text-gray-600">per month</div>
          </div>

          <div className="space-y-3">
            {features.map((feature, index) => (
              <div key={index} className="flex items-center space-x-3">
                <Check className="text-accent w-5 h-5" />
                <span>{feature}</span>
              </div>
            ))}
          </div>

          <Button 
            onClick={() => createCheckoutMutation.mutate()}
            disabled={createCheckoutMutation.isPending}
            className="w-full bg-accent hover:bg-green-600 text-white"
          >
            {createCheckoutMutation.isPending ? (
              "Creating checkout..."
            ) : (
              <>
                <Crown className="mr-2 w-4 h-4" />
                Upgrade to Pro
              </>
            )}
          </Button>

          <div className="text-center text-sm text-gray-600">
            <p>Cancel anytime • Secure payment via Stripe</p>
          </div>
        </CardContent>
      </Card>

      <Card className="bg-gray-50">
        <CardHeader>
          <CardTitle className="text-lg">Free Plan</CardTitle>
          <CardDescription>Your current plan includes:</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            <div className="flex items-center space-x-3">
              <Check className="text-gray-400 w-5 h-5" />
              <span className="text-gray-600">Access to landing page demo</span>
            </div>
            <div className="flex items-center space-x-3">
              <Check className="text-gray-400 w-5 h-5" />
              <span className="text-gray-600">Basic property information</span>
            </div>
            <div className="flex items-center space-x-3">
              <Check className="text-gray-400 w-5 h-5" />
              <span className="text-gray-600">Community support</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
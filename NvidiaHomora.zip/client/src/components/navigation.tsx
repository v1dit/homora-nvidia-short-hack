import { Button } from "@/components/ui/button";
import { Home, Github, Menu } from "lucide-react";
import { useState } from "react";

export default function Navigation() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setMobileMenuOpen(false);
  };

  const handleGitHubRedirect = () => {
    window.open("https://github.com/kgarg2468/Homora", "_blank");
  };

  return (
    <nav className="bg-white shadow-sm sticky top-0 z-50 border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <Home className="text-white w-5 h-5" />
            </div>
            <span className="text-xl font-bold text-secondary">Homora</span>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            <button 
              onClick={() => scrollToSection('features')} 
              className="text-gray-600 hover:text-primary transition-colors"
            >
              Features
            </button>
            <button 
              onClick={() => scrollToSection('demo')} 
              className="text-gray-600 hover:text-primary transition-colors"
            >
              Try Demo
            </button>
            <button 
              onClick={() => scrollToSection('install')} 
              className="text-gray-600 hover:text-primary transition-colors"
            >
              Install
            </button>
            <button 
              onClick={() => scrollToSection('docs')} 
              className="text-gray-600 hover:text-primary transition-colors"
            >
              Docs
            </button>
            <Button 
              onClick={() => window.location.href = "/auth"}
              className="bg-primary text-white hover:bg-blue-700"
            >
              Sign In
            </Button>
          </div>

          <button 
            className="md:hidden p-2"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            <Menu className="text-gray-600 w-6 h-6" />
          </button>
        </div>

        {mobileMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-100">
            <div className="flex flex-col space-y-4">
              <button 
                onClick={() => scrollToSection('features')} 
                className="text-gray-600 hover:text-primary transition-colors text-left"
              >
                Features
              </button>
              <button 
                onClick={() => scrollToSection('demo')} 
                className="text-gray-600 hover:text-primary transition-colors text-left"
              >
                Try Demo
              </button>
              <button 
                onClick={() => scrollToSection('install')} 
                className="text-gray-600 hover:text-primary transition-colors text-left"
              >
                Install
              </button>
              <button 
                onClick={() => scrollToSection('docs')} 
                className="text-gray-600 hover:text-primary transition-colors text-left"
              >
                Docs
              </button>
              <Button 
                onClick={() => window.location.href = "/auth"}
                className="bg-primary text-white hover:bg-blue-700 w-fit"
              >
                Sign In
              </Button>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}

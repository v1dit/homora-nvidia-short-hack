import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, Gavel, Info, Loader2 } from "lucide-react";
import { useState } from "react";

export default function DemoSection() {
  const [zipCode, setZipCode] = useState("94102");
  const [price, setPrice] = useState("$750,000");
  const [propertyType, setPropertyType] = useState("Single Family Home");
  const [analyzing, setAnalyzing] = useState(false);
  const [analysisComplete, setAnalysisComplete] = useState(false);

  const analyzeProperty = async () => {
    setAnalyzing(true);
    // Simulate analysis delay
    setTimeout(() => {
      setAnalyzing(false);
      setAnalysisComplete(true);
      setTimeout(() => {
        setAnalysisComplete(false);
      }, 3000);
    }, 2000);
  };

  return (
    <section id="demo" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl lg:text-4xl font-bold text-secondary mb-4">
            Try Homora Demo
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Experience the power of local real estate intelligence. This demo shows how Homora analyzes properties and provides insights.
          </p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl overflow-hidden border border-gray-100">
          <div className="gradient-hero text-white p-6">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-xl font-semibold">Property Analysis Dashboard</h3>
                <p className="text-blue-100 mt-1">Demo Mode - Real data requires local installation</p>
              </div>
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-accent rounded-full"></div>
                <span className="text-sm">Local Instance Running</span>
              </div>
            </div>
          </div>

          <div className="p-6">
            <div className="grid lg:grid-cols-3 gap-8">
              <div className="lg:col-span-1">
                <h4 className="text-lg font-semibold mb-4">Property Details</h4>
                <div className="space-y-4">
                  <div>
                    <Label className="text-sm font-medium text-gray-700 mb-1">ZIP Code</Label>
                    <Input 
                      type="text" 
                      placeholder="94102" 
                      value={zipCode}
                      onChange={(e) => setZipCode(e.target.value)}
                      className="w-full"
                    />
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-700 mb-1">Property Price</Label>
                    <Input 
                      type="text" 
                      placeholder="$750,000" 
                      value={price}
                      onChange={(e) => setPrice(e.target.value)}
                      className="w-full"
                    />
                  </div>
                  <div>
                    <Label className="text-sm font-medium text-gray-700 mb-1">Property Type</Label>
                    <Select value={propertyType} onValueChange={setPropertyType}>
                      <SelectTrigger className="w-full">
                        <SelectValue placeholder="Select property type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Single Family Home">Single Family Home</SelectItem>
                        <SelectItem value="Condo">Condo</SelectItem>
                        <SelectItem value="Townhouse">Townhouse</SelectItem>
                        <SelectItem value="Multi-Family">Multi-Family</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <Button 
                    onClick={analyzeProperty}
                    className="w-full bg-primary text-white hover:bg-blue-700"
                    disabled={analyzing}
                  >
                    {analyzing ? (
                      <>
                        <Loader2 className="mr-2 w-4 h-4 animate-spin" />
                        Analyzing...
                      </>
                    ) : analysisComplete ? (
                      <>
                        <TrendingUp className="mr-2 w-4 h-4" />
                        Analysis Complete
                      </>
                    ) : (
                      <>
                        <TrendingUp className="mr-2 w-4 h-4" />
                        Analyze Property
                      </>
                    )}
                  </Button>
                </div>
              </div>

              <div className="lg:col-span-2 space-y-6">
                <Card className="bg-gradient-to-br from-accent to-green-600 text-white">
                  <CardContent className="p-6">
                    <div className="flex items-center justify-between mb-4">
                      <h4 className="text-lg font-semibold">Investment Score</h4>
                      <div className="text-3xl font-bold">8.7</div>
                    </div>
                    <div className="space-y-3">
                      <div className="flex justify-between">
                        <span>Market Appreciation Potential</span>
                        <span className="font-medium">High</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Rental Yield Estimate</span>
                        <span className="font-medium">4.2%</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Risk Assessment</span>
                        <span className="font-medium">Medium-Low</span>
                      </div>
                    </div>
                    <div className="mt-4 pt-4 border-t border-green-400 border-opacity-30">
                      <p className="text-sm text-green-100">
                        AI Analysis: Strong growth indicators in this micro-market. Transit development and tech employment growth suggest continued appreciation.
                      </p>
                    </div>
                  </CardContent>
                </Card>

                <Card className="bg-neutral border border-gray-100">
                  <CardContent className="p-6">
                    <h4 className="text-lg font-semibold mb-4 flex items-center">
                      <Gavel className="text-blue-500 mr-2 w-5 h-5" />
                      Zoning & Legal Summary
                    </h4>
                    <div className="grid md:grid-cols-2 gap-6">
                      <div>
                        <h5 className="font-medium text-gray-900 mb-2">Current Zoning</h5>
                        <p className="text-gray-600 text-sm mb-3">R-2 Residential Medium Density</p>
                        
                        <h5 className="font-medium text-gray-900 mb-2">Permitted Uses</h5>
                        <ul className="text-sm text-gray-600 space-y-1">
                          <li>• Single-family dwellings</li>
                          <li>• Accessory dwelling units (ADUs)</li>
                          <li>• Home-based businesses (limited)</li>
                        </ul>
                      </div>
                      <div>
                        <h5 className="font-medium text-gray-900 mb-2">Recent Changes</h5>
                        <p className="text-gray-600 text-sm mb-3">ADU regulations updated in 2023 - now allows up to 1,200 sq ft units</p>
                        
                        <h5 className="font-medium text-gray-900 mb-2">Investment Impact</h5>
                        <div className="flex items-center space-x-2">
                          <Badge className="bg-accent text-white">Positive</Badge>
                          <span className="text-sm text-gray-600">ADU potential adds value</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <div className="grid md:grid-cols-3 gap-4">
                  <Card>
                    <CardContent className="p-4">
                      <div className="text-2xl font-bold text-primary">$825K</div>
                      <div className="text-sm text-gray-500">Median Price</div>
                      <div className="text-xs text-accent mt-1">↑ 12% YoY</div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <div className="text-2xl font-bold text-primary">18</div>
                      <div className="text-sm text-gray-500">Days on Market</div>
                      <div className="text-xs text-accent mt-1">↓ 5 days</div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4">
                      <div className="text-2xl font-bold text-primary">$892</div>
                      <div className="text-sm text-gray-500">Price/Sq Ft</div>
                      <div className="text-xs text-accent mt-1">↑ 8% YoY</div>
                    </CardContent>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="mt-8 bg-accent/10 border border-accent/30 rounded-lg p-4">
          <div className="flex items-center">
            <Info className="text-accent mr-3 w-5 h-5" />
            <div>
              <p className="text-accent font-medium">Ready to Get Started?</p>
              <p className="text-green-700 text-sm mt-1">
                This demo shows the interface. 
                <button 
                  onClick={() => window.location.href = "/auth"}
                  className="font-semibold text-accent hover:underline ml-1"
                >
                  Sign up now
                </button> 
                to access real AI-powered tools with live analysis.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

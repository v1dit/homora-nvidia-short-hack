import Navigation from "@/components/navigation";
import HeroSection from "@/components/hero-section";
import BenefitsSection from "@/components/benefits-section";
import DemoSection from "@/components/demo-section";
import FeaturesSection from "@/components/features-section";
import InstallationSection from "@/components/installation-section";
import TechStackSection from "@/components/tech-stack-section";
import CTASection from "@/components/cta-section";
import Footer from "@/components/footer";

export default function Landing() {
  return (
    <div className="min-h-screen bg-neutral">
      <Navigation />
      <HeroSection />
      <BenefitsSection />
      <DemoSection />
      <FeaturesSection />
      <InstallationSection />
      <TechStackSection />
      <CTASection />
      <Footer />
    </div>
  );
}

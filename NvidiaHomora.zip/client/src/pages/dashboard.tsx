import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Home, Brain, FileText, TrendingUp, Crown, LogOut, Settings } from "lucide-react";
import { useLocation } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { getQueryFn } from "@/lib/queryClient";
import AIToolsSection from "@/components/ai-tools-section";
import SubscriptionCard from "@/components/subscription-card";

interface User {
  id: number;
  email: string;
  fullName: string;
  subscriptionStatus: string;
}

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    const token = localStorage.getItem("token");
    
    if (!storedUser || !token) {
      setLocation("/auth");
      return;
    }
    
    try {
      setUser(JSON.parse(storedUser));
    } catch {
      setLocation("/auth");
    }
  }, [setLocation]);

  const { data: subscription } = useQuery({
    queryKey: ["/api/subscription"],
    queryFn: getQueryFn({ on401: "returnNull" }),
    enabled: !!user,
  });

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    setLocation("/");
  };

  const isPremium = user?.subscriptionStatus === "active" || subscription?.status === "active";

  if (!user) {
    return <div className="min-h-screen bg-neutral flex items-center justify-center">
      <div className="text-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
        <p>Loading...</p>
      </div>
    </div>;
  }

  return (
    <div className="min-h-screen bg-neutral">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                <Home className="text-white w-5 h-5" />
              </div>
              <span className="text-xl font-bold text-secondary">Homora</span>
              {isPremium && (
                <Badge className="bg-accent text-white">
                  <Crown className="w-3 h-3 mr-1" />
                  Pro
                </Badge>
              )}
            </div>
            
            <div className="flex items-center space-x-4">
              <span className="text-sm text-gray-600">Welcome, {user.fullName}</span>
              <Button variant="ghost" size="sm">
                <Settings className="w-4 h-4" />
              </Button>
              <Button variant="ghost" size="sm" onClick={handleLogout}>
                <LogOut className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-secondary mb-2">
            Real Estate Intelligence Dashboard
          </h1>
          <p className="text-gray-600">
            Access AI-powered tools for property analysis, investment scoring, and market insights.
          </p>
        </div>

        <Tabs defaultValue="tools" className="space-y-6">
          <TabsList>
            <TabsTrigger value="tools" className="flex items-center">
              <Brain className="w-4 h-4 mr-2" />
              AI Tools
            </TabsTrigger>
            <TabsTrigger value="subscription" className="flex items-center">
              <Crown className="w-4 h-4 mr-2" />
              Subscription
            </TabsTrigger>
          </TabsList>
          
          <TabsContent value="tools">
            <AIToolsSection isPremium={isPremium} />
          </TabsContent>
          
          <TabsContent value="subscription">
            <SubscriptionCard user={user} subscription={subscription} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
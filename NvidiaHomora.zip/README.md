# 🏡 Homora: Cloud-Based Real Estate Intelligence SaaS

Built for real estate professionals, investors, and renters who need AI-powered property insights.

## 🌟 What Is Homora?

Homora is a cloud-based SaaS platform providing AI-powered real estate intelligence. It offers investment scoring, legal document analysis, and rental fairness checking through a subscription-based model with working authentication and payment integration.

This project includes:
- Complete user authentication system
- Stripe payment integration for subscriptions
- Live AI tools for property analysis
- Professional dashboard interface

## 🎯 Key Features

- **🔐 Secure Authentication** - JWT-based user authentication with bcrypt password hashing
- **💳 Stripe Integration** - Working subscription payments and billing management
- **🧠 AI-Powered Tools** - Real investment scoring, document analysis, and rent fairness checking
- **📊 Professional Dashboard** - Clean interface for managing properties and subscriptions
- **⚡ Cloud-Based** - Instant access without installation requirements
- **🎯 Subscription Model** - Free tier with premium AI features available

## 🧰 Tech Stack

| Component | Technology | Location |
|-----------|------------|----------|
| UI/Website | React + Tailwind CSS | Replit/Web |
| Backend API | Express.js/FastAPI | Docker |
| AI Models | Ollama (llama3) | Docker |
| Automation | n8n | Docker |
| Database | PostgreSQL | Docker |

## 🚀 Quick Start

### Prerequisites
- Docker and Docker Compose installed
- Git

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/kgarg2468/Homora.git
   cd Homora
   ```

2. **Start all services**
   ```bash
   docker-compose up --build
   ```

3. **Access your local instance**
   - Main UI: http://localhost:8000
   - n8n Automation: http://localhost:5678
   - Ollama LLM API: http://localhost:11434
   - PostgreSQL: localhost:5432

## 🎮 Demo

Try the live demo at the landing page to see:
- Property investment scoring
- Zoning law analysis
- Market metrics comparison
- AI-powered insights

## 📡 API Endpoints

### Core Analysis
- `POST /api/property/analyze` - Property investment analysis with AI insights
- `GET /api/zoning/:zipcode` - Zoning information and legal compliance
- `GET /api/market/:region` - Market data and pricing trends

### Bulk Operations
- `POST /api/bulk/upload` - CSV property analysis for agencies
- `POST /api/rental/fairness` - Rental pricing fairness check

## 🏗️ Architecture

### Frontend (This Replit Project)
- **Framework**: React with TypeScript
- **UI Library**: Shadcn/ui components on Radix UI
- **Styling**: Tailwind CSS with dark/light themes
- **State Management**: React Query for server state
- **Routing**: Wouter for client-side navigation

### Backend (Docker Services)
- **API Server**: Express.js with TypeScript
- **Database**: PostgreSQL with Drizzle ORM
- **AI Engine**: Ollama running llama3 locally
- **Automation**: n8n for workflow processing
- **Storage**: In-memory demo storage with database interface

## 🔐 Privacy Benefits

Unlike Zillow or Redfin:
- ✅ Your data never leaves your machine
- ✅ Works even offline
- ✅ Customizable for agencies, NGOs, and investors
- ✅ No external API dependencies
- ✅ Complete control over AI models and data processing

## 🛠️ Development

### Running Locally (Development)
```bash
# Install dependencies
npm install

# Start development server
npm run dev
```

### Project Structure
```
├── client/          # React frontend
│   ├── src/
│   │   ├── components/  # UI components
│   │   ├── pages/       # Application pages
│   │   └── lib/         # Utilities and query client
├── server/          # Express.js backend
├── shared/          # Shared TypeScript schemas
└── docker-compose.yml  # Full production setup
```

## 🎯 Use Cases

- **Real Estate Agencies**: Bulk property analysis and client reporting
- **Property Investors**: Investment scoring and market analysis
- **Homebuyers**: Privacy-protected property research
- **Tenant Rights NGOs**: Rental fairness and regulation analysis

## 🗺️ Roadmap

- [x] Landing page and demo interface
- [ ] Real backend integration with Docker services
- [ ] Property upload → investment scoring pipeline
- [ ] Legal document summarization with Ollama
- [ ] User-specific dashboards (agency, buyer, tenant)
- [ ] Mobile-responsive enhancements
- [ ] Advanced market trend analysis

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

- 📚 [Documentation](https://github.com/kgarg2468/Homora/blob/main/API.md)
- 🐛 [Report Issues](https://github.com/kgarg2468/Homora/issues)
- 💬 [Discussions](https://github.com/kgarg2468/Homora/discussions)

## ⭐ Star History

If this project helps you, please consider giving it a star!

---

**Built with ❤️ for privacy-conscious real estate professionals**